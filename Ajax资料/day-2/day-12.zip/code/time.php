<?php
echo time();
