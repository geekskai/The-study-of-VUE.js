var data = {
  time: Date.now()
}

myonload(data)
