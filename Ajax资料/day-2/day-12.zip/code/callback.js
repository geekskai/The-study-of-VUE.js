// console.log(1)
// ajax('time.php', function (res) {
//   console.log(3)
//   ajax('time.php', function (res) {
//     ajax('time.php', function (res) {
//       ajax('time.php', function (res) {
//         ajax('time.php', function (res) {
//           ajax('time.php', function (res) {

//           })
//         })
//       })
//     })
//   })
//   console.log(4)
// })
// console.log(2)


// ajax('time.php')
//   .then(function (res) {
//     return ajax('time.php')
//   })
//   .then(function (res) {
//     return ajax('time.php')
//   })
//   .then(function (res) {
//     return ajax('time.php')
//   })
//   .then(function (res) {
//     return ajax('time.php')
//   })

// function load () {
//   ajax('time.php', load)
// }
